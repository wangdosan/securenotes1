<?php
// Check if user is logged in (by verifying session)
session_start();
if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>SecureNotes - Profile</title>
    <!-- CSS styling for cyber security theme -->
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
  /* styles.css */

body {
  margin: 0;
  padding: 0;
  margin: 0;
  padding: 0;
  background-color: #000;
    color: #00ff00;
    font-family: "Courier New", monospace;
    display: flex;
    flex-direction: column;
}

.navbar {
  background-color: #333;
  overflow: hidden;
}

.navbar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.navbar li {
  float: left;
}

.navbar li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Gaya untuk teks yang berada di tengah halaman */
.center-text {
  display: flex;
  justify-content: center;
  align-items: center;
}

/* Gaya saat kursor di atas teks */
.navbar li a:hover {
  background-color: green; /* Warna latar belakang saat dihover (hijau) */
}
/* Gaya untuk gambar logo */
.logo {
        position: absolute;
        top: 10%;
        left: 10%;
        transform: translate(-50%, -50%);
        max-width: 200px;
    }
  .btn{
    background-color: #0f0;
  }

</style>
<body>
<img class="logo" src="logo.png" alt="Logo">  
<nav class="navbar center-text">
    <ul>
    <li><a href="dashboard.php">Home</a></li>
      <li><a href="profil.php">Profile</a></li>
      <li><a href="add_note.php">Add Note</a></li>
      <li><a href="index.php">Logout</a></li>
    </ul>
  </nav>
    <div class="container">
        <h2>Profile</h2>
        <p>Username: <?php echo $_SESSION["username"]; ?></p>
        <a href="change_password.php">Change Password</a>
    <form action="generate_passcode.php" method="post">
      <div class="input-group">
        <label for="password">Password:</label>
        <input type="password" name="password" required>
      <div class="input-group">
        <button type="submit" name="generate_btn" class="btn">Generate Passcode</button>
      </div>
    </form>
  </div>
    </div>
</body>
</html>
