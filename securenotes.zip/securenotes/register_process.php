<?php
// Kode untuk mengelola proses registrasi

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validasi data (pastikan data tidak kosong, dll. sesuai kebutuhan Anda)
    if (empty($username) || empty($password)) {
        header("Location: register.php?error=emptyfields");
        exit();
    }

    // Lakukan validasi lain sesuai kebutuhan, misalnya cek apakah username sudah digunakan sebelumnya.

    // Hubungkan ke database MySQL
    $servername = "localhost"; // Ganti dengan nama server database Anda
    $username_db = "root"; // Ganti dengan username database Anda
    $password_db = ""; // Ganti dengan password database Anda
    $dbname = "dbsecurenotes"; // Ganti dengan nama database Anda

    $conn = mysqli_connect($servername, $username_db, $password_db, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Lakukan enkripsi password menggunakan metode AES 128 (Anda perlu menggantinya dengan library kriptografi yang tepat)
    $encrypted_password = encryptPassword($password);

    // Masukkan data ke database
    $sql = "INSERT INTO users (username, password) VALUES ('$username', '$encrypted_password')";
    if (mysqli_query($conn, $sql)) {
        // Redirect ke halaman login setelah registrasi berhasil
        header("Location: index.php?success=registered");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
}

// Fungsi untuk mengenkripsi password menggunakan AES 128 (contoh sederhana, pastikan menggunakan library kriptografi yang tepat)
function encryptPassword($password)
{
    // Implementasikan enkripsi AES 128 di sini sesuai kebutuhan Anda
    // Contoh sederhana: return md5($password);

    return $password; // Sebagai contoh, kembalikan password tanpa enkripsi
}
