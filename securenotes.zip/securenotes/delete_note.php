<?php
// delete_note.php

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['id'])) {
  $note_id = $_GET['id'];

  // Hapus catatan dari database (contoh sederhana, ganti dengan kode penghapusan sesungguhnya)
  $servername = "localhost"; // Ganti dengan nama server database Anda
  $username_db = "root"; // Ganti dengan username database Anda
  $password_db = ""; // Ganti dengan password database Anda
  $dbname = "dbsecurenotes"; // Ganti dengan nama database Anda

  $conn = mysqli_connect($servername, $username_db, $password_db, $dbname);

  if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
  }

  $sql = "DELETE FROM notes WHERE id='$note_id'"; // Ganti 'notes' dengan nama tabel catatan Anda
  if (mysqli_query($conn, $sql)) {
    header("Location: dashboard.php");
    exit();
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);
}
