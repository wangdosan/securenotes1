<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Validasi data (pastikan data tidak kosong, dll. sesuai kebutuhan Anda)
    if (empty($username) || empty($password)) {
        header("Location: login.php?error=emptyfields");
        exit();
    }

    // Hubungkan ke database MySQL
    $servername = "localhost"; // Ganti dengan nama server database Anda
    $username_db = "root"; // Ganti dengan username database Anda
    $password_db = ""; // Ganti dengan password database Anda
    $dbname = "dbsecurenotes"; // Ganti dengan nama database Anda

    $conn = mysqli_connect($servername, $username_db, $password_db, $dbname);

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Cari pengguna berdasarkan username
    $sql = "SELECT * FROM users WHERE username='$username'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);

        // Lakukan verifikasi password (perhatikan bahwa ini hanya contoh sederhana)
        // Anda harus menggunakan metode enkripsi yang sesuai untuk memverifikasi password.
        if ($password === $row['password']) {
            // Password cocok, berarti login berhasil
            $_SESSION['username'] = $username;
            header("Location: dashboard.php"); // Ganti dengan halaman dashboard Anda
            exit();
        } else {
            // Password tidak cocok, kembali ke halaman login
            header("Location: index.php?error=invalidlogin");
            exit();
        }
    } else {
        // Pengguna tidak ditemukan, kembali ke halaman login
        header("Location: index.php?error=invalidlogin");
        exit();
    }

    mysqli_close($conn);
}
