<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SecureNotes - Add Note</title>
  <link rel="stylesheet" href="style.css">
</head>
<style>
  /* styles.css */

body {
  margin: 0;
  padding: 0;
  margin: 0;
  padding: 0;
  background-color: #000;
    color: #00ff00;
    font-family: "Courier New", monospace;
    display: flex;
    flex-direction: column;
}

.navbar {
  background-color: #333;
  overflow: hidden;
}

.navbar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.navbar li {
  float: left;
}

.navbar li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Gaya untuk teks yang berada di tengah halaman */
.center-text {
  display: flex;
  justify-content: center;
  align-items: center;
}

/* Gaya saat kursor di atas teks */
.navbar li a:hover {
  background-color: green; /* Warna latar belakang saat dihover (hijau) */
}
/* Gaya untuk gambar logo */
.logo {
        position: absolute;
        top: 10%;
        left: 10%;
        transform: translate(-50%, -50%);
        max-width: 200px;
    }
input[type="submit"] {
        padding: 10px 20px;
        font-size: 16px;
        background-color: #00ff00;
        border: none;
        color: #000;
        cursor: pointer;
        outline: none;
    }
    input[type="submit"]:hover {
        background-color: #0f0;
    }

</style>
<body>
<img class="logo" src="logo.png" alt="Logo">  
<nav class="navbar center-text">
    <ul>
    <li><a href="dashboard.php">Home</a></li>
      <li><a href="profil.php">Profile</a></li>
      <li><a href="add_note.php">Add Note</a></li>
      <li><a href="index.php">Logout</a></li>
    </ul>
  </nav>

  <div class="container">
    <h2>Add New Note</h2>
    <form action="save_note.php" method="post">
      <div class="input-group">
        <label for="note">Note:</label>
        <textarea name="note" rows="4" required></textarea>
      </div>
      <div class="input-group">
      <input type="submit" value="Save Note">
      </div>
    </form>
  </div>
</body>
</html>
