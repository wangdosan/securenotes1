<?php
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $passcode = $_POST['passcode'];
  $username = $_SESSION['username'];

  if (verifyPasscode($passcode, $username)) {
    $note_id = $_GET['id']; // ID catatan yang ingin didekripsi
    $note = getEncryptedNote($note_id);
    
    $key = "MySecretKey123"; // Harus sama dengan kunci yang digunakan untuk enkripsi
    $decrypted_note = decryptContent($note, $key);
    
    echo "The decrypted note is: " . $decrypted_note;
  } else {
    echo "Invalid passcode!";
  }
}

function verifyPasscode($input_passcode, $username) {
  $conn = new mysqli("localhost", "root", "", "dbsecurenotes");

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT passcode FROM users WHERE username = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();
  $user = $result->fetch_assoc();

  return $user && $user['passcode'] === $input_passcode;
}

function getEncryptedNote($note_id) {
  $conn = new mysqli("localhost", "root", "", "dbsecurenotes");

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $sql = "SELECT note FROM notes WHERE id = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("i", $note_id);
  $stmt->execute();
  $result = $stmt->get_result();
  $note = $result->fetch_assoc();

  return $note ? $note['note'] : null;
}

function decryptContent($encrypted_content, $key) {
  $cipher = "aes-128-cbc";
  $ivlen = openssl_cipher_iv_length($cipher);
  
  $encrypted_content = base64_decode($encrypted_content);
  $iv = substr($encrypted_content, 0, $ivlen);
  $encrypted_note = substr($encrypted_content, $ivlen);
  
  $decrypted_content = openssl_decrypt($encrypted_note, $cipher, $key, OPENSSL_RAW_DATA, $iv);
  
  return $decrypted_content;
}
?>

<form action="decrypt_note.php?id=<?php echo $_GET['id']; ?>" method="post">
  <label for="passcode">Enter your passcode:</label><br>
  <input type="password" id="passcode" name="passcode"><br>
  <input type="submit" value="Decrypt">
</form>
