<?php
session_start();

// Cek jika passcode ada dalam session
if (isset($_SESSION['generated_passcode'])) {
  $passcode = $_SESSION['generated_passcode'];
  unset($_SESSION['generated_passcode']); // Hapus passcode dari session setelah ditampilkan
} else {
  // Jika passcode tidak ada dalam session, redirect ke halaman login
  header("Location: login.php");
  exit();
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Your Generated Passcode</title>
  <!-- Tambahkan CSS dan lainnya sesuai kebutuhan -->
</head>
<body>
  <h1>Your generated passcode is: <?php echo $passcode; ?></h1>
  <!-- Tambahkan navigasi dan lainnya sesuai kebutuhan -->
</body>
</html>
