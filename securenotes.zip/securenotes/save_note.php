<?php
session_start();
$username = $_SESSION['username'];
// save_note.php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $note = $_POST['note'];

   // Enkripsi catatan menggunakan AES 128 dengan kunci tertentu (contoh sederhana, ganti dengan kode enkripsi sesungguhnya)
   $encryption_key = 'MySecretKey123'; // Ganti dengan kunci yang lebih aman dan tidak mudah ditebak
   $encrypted_note = encryptContent($note, $encryption_key);
 
   // Simpan catatan terenkripsi ke database (contoh sederhana, ganti dengan kode penyimpanan sesungguhnya)
   $servername = "localhost"; // Ganti dengan nama server database Anda
   $username_db = "root"; // Ganti dengan username database Anda
   $password_db = ""; // Ganti dengan password database Anda
   $dbname = "dbsecurenotes"; // Ganti dengan nama database Anda
 
   $conn = mysqli_connect($servername, $username_db, $password_db, $dbname);
 
   if (!$conn) {
       die("Connection failed: " . mysqli_connect_error());
   }
 
$sql = "INSERT INTO notes (note, username) VALUES (?, ?)"; 
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $encrypted_note, $username);

if ($stmt->execute()) {
  header("Location: dashboard.php");
  exit();
} else {
  echo "Error: " . $sql . "<br>" . $stmt->error;
}
   mysqli_close($conn);
 }
 
 // Fungsi untuk mengenkripsi catatan menggunakan AES 128
 function encryptContent($content, $key) {
   // Ganti dengan implementasi enkripsi AES 128 sesuai kebutuhan Anda
   // Berikut adalah contoh menggunakan library openssl
   $cipher = "aes-128-cbc";
   $ivlen = openssl_cipher_iv_length($cipher);
   $iv = openssl_random_pseudo_bytes($ivlen);
   $encrypted_content = openssl_encrypt($content, $cipher, $key, OPENSSL_RAW_DATA, $iv);
   $encrypted_content = base64_encode($iv . $encrypted_content);
   return $encrypted_content;
 }

 