<?php
session_start();

// Pengaturan koneksi database Anda
$dbHost = "localhost";
$dbUser = "root";
$dbPass = "";
$dbName = "dbsecurenotes";

// Membuat koneksi
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

// Memeriksa koneksi
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $currentPassword = $_POST["current_password"];
    $newPassword = $_POST["new_password"];
    $username = $_SESSION["username"];

    // Lakukan validasi data jika diperlukan
    if(empty($newPassword) || empty($currentPassword)){
        header("Location: change_password.php?error=Empty field");
        exit();
    }

    // Cek apakah password saat ini (currentPassword) sudah benar
    $sql = "SELECT password FROM users WHERE username = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $username);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        $row = $result->fetch_assoc();

        if ($currentPassword != $row["password"]) {
            // Jika password saat ini tidak cocok, redirect kembali dengan pesan error
            header("Location: change_password.php?error=Incorrect current password");
            exit();
        } else {
            // Jika benar, lakukan update password di database
            $sql = "UPDATE users SET password = ? WHERE username = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $newPassword, $username);

            if ($stmt->execute()) {
                // Redirect kembali ke halaman profil dengan pesan sukses
                header("Location: profil.php?message=Password changed successfully");
                exit();
            } else {
                // Jika ada error saat eksekusi query, redirect kembali dengan pesan error
                header("Location: change_password.php?error=Failed to change password");
                exit();
            }
        }
    } else {
        // Jika ada error saat eksekusi query, redirect kembali dengan pesan error
        header("Location: change_password.php?error=Failed to change password");
        exit();
    }
}
