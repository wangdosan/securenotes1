<?php
session_start(); // Memastikan session di-start
$username = $_SESSION['username'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['generate_btn'])) {
  $password = $_POST['password'];
  $username = $_SESSION['username']; // Mengambil username dari session
  
  // Panggil fungsi untuk melakukan verifikasi password
  if (verifyPassword($password, $username)) {
    // Jika password valid, lakukan generate passcode
    $passcode = generateRandomPasscode(8);
    
    // Panggil fungsi untuk menyimpan passcode ke database
    savePasscodeToDatabase($username, $passcode);

    // Simpan passcode ke session untuk ditampilkan di halaman berikutnya
    $_SESSION['generated_passcode'] = $passcode;

    // Redirect ke halaman baru yang akan menampilkan passcode
    header("Location: show_passcode.php");
    exit();
  } else {
    echo "Invalid password!";
  }
}

// Fungsi untuk generate passcode random
function generateRandomPasscode($length) {
  $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  $passcode = '';
  for ($i = 0; $i < $length; $i++) {
    $index = rand(0, strlen($characters) - 1);
    $passcode .= $characters[$index];
  }
  return $passcode;
}

// Fungsi untuk melakukan verifikasi password
function verifyPassword($input_password, $username) {
  $conn = new mysqli("localhost", "root", "", "dbsecurenotes");

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  // Mengambil password dari database
  $sql = "SELECT password FROM users WHERE username = ?";
  $stmt = $conn->prepare($sql);
  $stmt->bind_param("s", $username);
  $stmt->execute();
  $result = $stmt->get_result();
  $user = $result->fetch_assoc();

  // Membandingkan password input dengan password di database
  if ($user && $user['password'] === $input_password) {
    return true;
  } else {
    return false;
  }
}

// Fungsi untuk menyimpan passcode ke database
function savePasscodeToDatabase($username, $passcode) {
  $conn = new mysqli("localhost", "root", "", "dbsecurenotes");

  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }

  $username = mysqli_real_escape_string($conn, $username);
  $passcode = mysqli_real_escape_string($conn, $passcode);

  $sql = "UPDATE users SET passcode='$passcode' WHERE username='$username'"; // Ganti 'users' dengan nama tabel pengguna Anda
  if (mysqli_query($conn, $sql)) {
    // Passcode berhasil disimpan
  } else {
    echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }

  mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Generate Passcode</title>
  <!-- Tambahkan CSS dan lainnya sesuai kebutuhan -->
</head>
<body>
  <form action="generate_passcode.php" method="post">
    <label for="password">Enter your password:</label><br>
    <input type="password" id="password" name="password"><br>
    <input type="submit" name="generate_btn" value="Generate Passcode">
  </form>
  <!-- Tambahkan navigasi dan lainnya sesuai kebutuhan -->
</body>
</html>
