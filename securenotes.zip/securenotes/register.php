<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SecureNotes - Register</title>
  <link rel="stylesheet" href="style.css">
</head>
<style>
    body {
        background-color: #000;
        color: #00ff00;
        font-family: "Courier New", monospace;
        padding: 20px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        height: 100vh;
    }
    .logo {
        position: absolute;
        top: 10%;
        left: 10%;
        transform: translate(-50%, -50%);
        max-width: 200px;
    }
    h1 {
        font-size: 28px;
        text-align: center;
    }
    form {
        margin-top: 30px;
        text-align: center;
    }
    input[type="text"],
    input[type="password"] {
        padding: 10px;
        width: 300px;
        font-size: 16px;
        background-color: #111;
        border: 2px solid #00ff00;
        color: #00ff00;
        outline: none;
    }
    input[type="text"]:focus,
    input[type="password"]:focus {
        border-color: #0f0;
    }
    input[type="submit"] {
        padding: 10px 20px;
        font-size: 16px;
        background-color: #00ff00;
        border: none;
        color: #000;
        cursor: pointer;
        outline: none;
    }
    input[type="submit"]:hover {
        background-color: #0f0;
    }
    p {
        text-align: center;
        margin-top: 20px;
    }
    a {
        color: #00ff00;
        text-decoration: none;
    }
    a:hover {
        color: #0f0;
    }
  </style>
<body>
<div class="container">
    <form action="register_process.php" method="post">
    <img class="logo" src="logo.png" alt="Logo">   
      <h2>SecureNotes - Register</h2>
      <?php
      if (isset($_GET['error'])) {
        if ($_GET['error'] === 'emptyfields') {
          echo '<p class="error">Please fill in all fields.</p>';
        } elseif ($_GET['error'] === 'userexists') {
          echo '<p class="error">Username already exists. Please choose a different username.</p>';
        }
      }
      ?>
      <div class="input-group">
        <label for="username">Username:</label>
        <input type="text" name="username" required>
      </div>
      <div class="input-group">
        <label for="password">Password:</label>
        <input type="password" name="password" required>
      </div>
      <div class="input-group">
      <input type="submit" value="Register">
      </div>
      <p>Already have an account? <a href="index.php">Login</a></p>
    </form>
  </div>
</div>
</body>
</html>
