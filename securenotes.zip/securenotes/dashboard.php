<?php
// Check if user is logged in (by verifying session)
session_start();
$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>SecureNotes - Home</title>
    <!-- CSS styling for cyber security theme -->
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<style>
  /* styles.css */

  

body {
  margin: 0;
  padding: 0;
  background-color: #000;
    color: #00ff00;
    font-family: "Courier New", monospace;
    display: flex;
    flex-direction: column;
}

.navbar {
  background-color: #333;
  overflow: hidden;
}

.navbar ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.navbar li {
  float: left;
}

.navbar li a {
  display: block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Gaya untuk teks yang berada di tengah halaman */
.center-text {
  display: flex;
  justify-content: center;
  align-items: center;
}

/* Gaya saat kursor di atas teks */
.navbar li a:hover {
  background-color: green; /* Warna latar belakang saat dihover (hijau) */
}
/* Gaya untuk gambar logo */
.logo {
        position: absolute;
        top: 10%;
        left: 10%;
        transform: translate(-50%, -50%);
        max-width: 200px;
    }
.container {
        width: 1000px;
}
</style>
<body>
<img class="logo" src="logo.png" alt="Logo">  
<nav class="navbar center-text">
    <ul>
    <li><a href="dashboard.php">Home</a></li>
      <li><a href="profil.php">Profile</a></li>
      <li><a href="add_note.php">Add Note</a></li>
      <li><a href="index.php">Logout</a></li>

    </ul>
  </nav>
    <div class="container">
        <h2>Welcome, <?php echo $_SESSION["username"]; ?>!</h2>
        <!-- Display encrypted notes here from the database -->
        <table>
      <tr>
        <th>Note</th>
        <th>Actions</th>
      </tr>
      <?php
      // Ambil catatan dari database (contoh sederhana, ganti dengan kueri ke database sesungguhnya)
      $servername = "localhost"; // Ganti dengan nama server database Anda
      $username_db = "root"; // Ganti dengan username database Anda
      $password_db = ""; // Ganti dengan password database Anda
      $dbname = "dbsecurenotes"; // Ganti dengan nama database Anda

      $conn = mysqli_connect($servername, $username_db, $password_db, $dbname);

      if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
      }

      $sql = "SELECT * FROM notes WHERE username = ?"; // Ganti 'notes' dengan nama tabel catatan Anda
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

while ($row = mysqli_fetch_assoc($result)) {
    echo '<tr>';
    echo '<td>' . $row['note'] . '</td>';
    echo '<td>';
    echo '<a href="decrypt_note.php?id=' . $row['id'] . '">Decrypt</a> ';
    echo '<a href="delete_note.php?id=' . $row['id'] . '">Delete</a>';
    echo '</td>';
    echo '</tr>';
}

      mysqli_close($conn);
      ?>
    </table>
    </div>
</body>
</html>
